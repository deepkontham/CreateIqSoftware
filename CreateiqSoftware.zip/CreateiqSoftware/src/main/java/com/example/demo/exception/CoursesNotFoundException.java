package com.example.demo.exception;

public class CoursesNotFoundException extends Exception {

	public CoursesNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
